package Teng::Plugin::Resultset;
use strict;
use warnings;
our $VERSION = '0.01';

our @EXPORT = qw/
    resultset
    search_from_resultset
    count_from_resultset
/;

sub resultset {
    my ($self, %params) = @_;
    my $select = $params{select};  $select = [$select || ()]  if (ref $select) eq '';
    my $from   = $params{from};    $from   = [$from   || ()]  if (ref $from)   eq '';
    my $where  = $params{where};   $where  = [$where  || ()]  if (ref $where)  eq '';
    my $join   = $params{join};

    my $rs = $self->sql_builder->new_select( quote_char => q{} );

    # select
    for my $i ( @$select ) {
        my $c;
        if ( ref $i eq 'ARRAY' ) { $c = $self->column(@$i) }
        else                     { $c = $i }
        $rs->add_select(\$c);
    }

    # from: join が定義されているときはスルーする
    if ( ! defined $join ) {
        for my $i ( @$from ) {
            my $t;
            if ( ref $i eq 'ARRAY' ) { $t = $self->table(@$i) }
            else                     { $t = $i }
            $rs->add_from($t);
        }
    }

    # where
    my $where_ = [ @$where ];
    while ( @$where_ ) {
        my ($l, $r) = ( shift(@$where_), shift(@$where_) );
        $l = $self->column(@$l)  if (ref $l) eq 'ARRAY';
        $rs->add_where(\$l => $r);
    }

    # join
    if ( (ref $join) eq 'HASH' ) {
        if ( @$from ) {
            $join = [ $from->[0] =>  $join ];
        }
    }
    if ( (ref $join) eq 'ARRAY' ) {
        my @join_ = @$join;
        while ( @join_ ) {
            my ($table, $targets) = ( shift(@join_), shift(@join_) );
            if ( ref $table eq 'ARRAY' ) {
                my ($t, $a) = @$table;
                $table = [ $self->table($t), $a ];
            }
            if ( ref $targets eq 'HASH' ) {
                $targets = [ $targets ];
            }
            for my $target ( @$targets ) {
                $target->{table} = $self->table(@{$target->{table}})  if (ref $target->{table}) eq 'ARRAY';
                $rs->add_join( $table, $target );
            }
        }
    }

    return $rs;
}

sub search_from_resultset {
    my ($self, $rs, $table) = @_;
    return $self->search_by_sql( $rs->as_sql, [$rs->bind], $table );
}

sub count_from_resultset {
    my ($self, $rs, $col, $opts) = @_;
    return  unless  defined $rs  &&  defined $col;
    $opts = +{}  unless  defined $opts  &&  ref($opts) eq 'HASH';

    my $count = 0;

    # すげ替え対象のプロパティを保持する
    my $prev = +{
        select => $rs->{select},
        limit  => $rs->{limit},
        offset => $rs->{offset},
        group  => $rs->{group},
    };

    # COUNT文発行に向けてプロパティをすげ替える
    $rs->{select} = [
        $self->column(
            $col->[0], $col->[1], 'cnt',
            sub { $opts->{distinct} ? "COALESCE( COUNT(DISTINCT $_[1]), 0 )" : "COALESCE( COUNT($_[1]), 0 )" },
        ),
    ];
    delete $rs->{limit};
    delete $rs->{offset};
    $rs->{group_by} = [];

    if ( $opts->{__return_resultset_before_search} ) {
        return $rs;
    }

    my $itr = $self->search_from_resultset($rs);
    $itr->suppress_object_creation(1);
    $count = $itr->next->{cnt};

    # すげ替えたプロパティを元に戻す
    $rs->{select}   = $prev->{select};
    $rs->{limit}    = $prev->{limit}   if defined $prev->{limit};
    $rs->{offset}   = $prev->{offset}  if defined $prev->{offset};
    $rs->{group_by} = $prev->{group}   if defined $prev->{group};

    return $count;
}

1;
__END__

=head1 NAME

Teng::Plugin::Resultset -

=head1 SYNOPSIS

  use Teng::Plugin::Resultset;

=head1 DESCRIPTION

Teng::Plugin::Resultset is

=head1 AUTHOR

issm E<lt>issmxx@gmail.comE<gt>

=head1 SEE ALSO

=head1 LICENSE

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut
