package Teng::Plugin::Utils;
use strict;
use warnings;
our $VERSION = '0.01';

our @EXPORT = qw/
    table
    column
/;

sub table {
    my ($self, $name, $alias) = @_;
    return  unless defined $name;

    my $ret = ( $self->{table_prefix} || '' ) . $name;
    $ret = "$ret $alias"  if defined $alias;

    return $ret;
}

sub column {
    my ($self, $name, $table, $alias, $sub) = @_;
    return  unless defined $name;

    my $col_name = $name;
    my $pre = $self->{table_prefix};

    if (defined $table) {
        if (my ($table_alias) = $table =~ /^-(.*)$/) {
            $col_name = "${table_alias}.${name}"
                if $table_alias ne '';
        }
        else {
            $col_name = "${table}.${name}";
            $col_name = "${pre}${col_name}"  if defined $pre;
        }
    }

    if (defined $sub  &&  ref $sub eq 'CODE') {
        $col_name = $sub->($self, $col_name)
    }

    return (defined $alias  &&  $alias ne '-')  ?  "$col_name $alias"  :  $col_name;
}

1;
__END__

=head1 NAME

Teng::Plugin::Utils -

=head1 SYNOPSIS

  use Teng::Plugin::Utils;

=head1 DESCRIPTION

Teng::Plugin::Utils is

=head1 AUTHOR

issm E<lt>issmxx@gmail.comE<gt>

=head1 SEE ALSO

=head1 LICENSE

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut
