package Amon2::Plugin::Teng;
use strict;
use warnings;
use DBI;
use Class::Load;

our $VERSION = '0.01';

sub init {
    my ($class, $context_class, $config) = @_;
    my $db_class = (split /::/, $context_class)[0] . '::DB';
    no strict 'refs';
    *{"$context_class\::teng"} = *{"$context_class\::db"} = \&_teng;
    *{"$context_class\::__db_class"} = sub { $db_class };
}

sub _teng {
    my ($self) = @_;
    if ( ! defined $self->{teng} ) {
        my $conf = $self->config->{'Teng'};
        my $schema_class = $conf->{schema_class}
            or  die "config.Teng.schema_class is not defined!";
        my $dbh = DBI->connect( @$conf{qw/dsn username password connect_options/} )
            or die "Cannot connect to DB:: " . $DBI::errstr;
        Class::Load::load_class( $schema_class )
            or die "Cannot load class $schema_class: $!";

        $self->{teng} = $self->{db} = $self->__db_class->new({
            dbh          => $dbh,
            table_prefix => $conf->{table_prefix} || '',
        });
    }
    return $self->{teng};
}

1;
__END__

=head1 NAME

Amon2::Plugin::Teng -

=head1 SYNOPSIS

  use Amon2::Plugin::Teng;

=head1 DESCRIPTION

Amon2::Plugin::Teng is

=head1 AUTHOR

issm E<lt>issmxx@gmail.comE<gt>

=head1 SEE ALSO

=head1 LICENSE

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut
