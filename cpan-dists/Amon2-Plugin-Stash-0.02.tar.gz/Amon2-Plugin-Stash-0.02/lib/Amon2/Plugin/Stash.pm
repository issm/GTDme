package Amon2::Plugin::Stash;
use strict;
use warnings;
our $VERSION = '0.02';
use Scope::Container;

sub init {
    my ($class, $context_class, $config) = @_;

    no strict 'refs';
    *{"$context_class\::stash"}   = \&_stash;
    *{"$context_class\::_render"} = \&Amon2::Web::render;
    *{"$context_class\::render"}  = \&_render_with_stash;
}

sub _stash {
    my ($self, %params) = @_;

    if ( in_scope_container() ) {
        my $stash = scope_container('stash');
        unless ( defined $stash ) {
            $stash = +{};
            scope_container('stash', $stash);
        }
        return $stash;
    }
    else {
        unless ( defined $self->{__stash__} ) { $self->{__stash__} = +{} }
        return $self->{__stash__};
    }
}

sub _render_with_stash {
    my ($self, $tmpl, $vars) = @_;
    my $stash = ( in_scope_container() ?  scope_container('stash') : $self->{__stash__} ) || {};
    return $self->_render( $tmpl, +{
        %$stash,
        %{ defined $vars && ref($vars) eq 'HASH' ? $vars : {} },
    });
}

1;
__END__

=head1 NAME

Amon2::Plugin::Stash -

=head1 SYNOPSIS

  use Amon2::Plugin::Stash;

=head1 DESCRIPTION

Amon2::Plugin::Stash is

=head1 AUTHOR

issm E<lt>issmxx@gmail.comE<gt>

=head1 SEE ALSO

=head1 LICENSE

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut
